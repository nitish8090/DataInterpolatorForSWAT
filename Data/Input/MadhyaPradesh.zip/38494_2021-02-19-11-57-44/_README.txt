Weater data requested on 2/19/2021 11:57 AM.

South Latitude: 22.0492
West Longitude: 74.5892
North Latitude: 22.7399
East Longitude: 75.6539
Number of Weather Stations: 8

Start Date: 1/1/2000
End Date: 7/31/2014

Data Collected:
Temperature (C): Yes
Precipitation (mm): Yes
Wind (m/s): Yes
Relative Humidity (fraction): Yes
Solar (MJ/m^2): Yes

Generate SWAT Files? Yes
Generate CSV File? Yes
