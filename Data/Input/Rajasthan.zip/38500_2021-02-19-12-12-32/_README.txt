Weater data requested on 2/19/2021 12:12 PM.

South Latitude: 23.8371
West Longitude: 73.5376
North Latitude: 24.5498
East Longitude: 74.6837
Number of Weather Stations: 9

Start Date: 1/1/2000
End Date: 7/31/2014

Data Collected:
Temperature (C): Yes
Precipitation (mm): Yes
Wind (m/s): Yes
Relative Humidity (fraction): Yes
Solar (MJ/m^2): Yes

Generate SWAT Files? Yes
Generate CSV File? Yes
