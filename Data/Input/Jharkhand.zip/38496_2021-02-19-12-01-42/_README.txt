Weater data requested on 2/19/2021 12:01 PM.

South Latitude: 23.9222
West Longitude: 84.9705
North Latitude: 24.5677
East Longitude: 85.7995
Number of Weather Stations: 6

Start Date: 1/1/2000
End Date: 7/31/2014

Data Collected:
Temperature (C): Yes
Precipitation (mm): Yes
Wind (m/s): Yes
Relative Humidity (fraction): Yes
Solar (MJ/m^2): Yes

Generate SWAT Files? Yes
Generate CSV File? Yes
