Weater data requested on 2/19/2021 12:26 PM.

South Latitude: 23.5986
West Longitude: 72.7354
North Latitude: 24.2404
East Longitude: 73.692
Number of Weather Stations: 6

Start Date: 1/1/2000
End Date: 7/31/2014

Data Collected:
Temperature (C): Yes
Precipitation (mm): Yes
Wind (m/s): Yes
Relative Humidity (fraction): Yes
Solar (MJ/m^2): Yes

Generate SWAT Files? Yes
Generate CSV File? Yes
