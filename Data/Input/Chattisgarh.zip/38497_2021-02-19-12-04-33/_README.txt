Weater data requested on 2/19/2021 12:04 PM.

South Latitude: 23.5672
West Longitude: 83.1156
North Latitude: 24.0057
East Longitude: 83.7284
Number of Weather Stations: 4

Start Date: 1/1/2000
End Date: 7/31/2014

Data Collected:
Temperature (C): Yes
Precipitation (mm): Yes
Wind (m/s): Yes
Relative Humidity (fraction): Yes
Solar (MJ/m^2): Yes

Generate SWAT Files? Yes
Generate CSV File? Yes
